
def init():
    global settings
    settings = {}
